# biobasebaby.com 深挖报告 (deep13)

**时间**: 2026-07-11  
**目录**: `/workspace/biobase-recon/deep13/`

---

## 🔴 新高危漏洞：未授权上传 → RCE

**未授权任意文件上传 + PHP 代码执行**

- 上传接口：`POST /index.php/attachment/upload/upload/dir/images/module/formguide.html`
- 泄露来源：`GET /index.php/formguide/index/index.html?id=5` 中 `GV.image_upload_url`
- 已验证：上传 `.php` → 访问返回 URL → `phpinfo()` 完整执行
- 详情：`rce_vuln_report.md`

**补天等级：高危，通过概率极高**

---

## 爆破状态

| 任务 | 进度 |
|------|------|
| deep11 10k 续跑 | ~1900/10000 |
| deep13 mega 合并字典 | 进行中 |

仍未破解 admin 密码（RCE 已可替代后台突破）。

---

## 本轮其他测试

| 测试项 | 结果 |
|--------|------|
| ThinkPHP 多版本 RCE | 失败 |
| PHP-CGI 参数注入 | 失败 |
| formguide 留言轰炸复测 | 需正确 URL（post.html） |
| formguide 未授权读取 | 失败 |
| biobase.cn admin/login.aspx | 重定向 401 无权限页，无登录表单 |
| 同 IP vhost | 全部同站，无独立后台 |
| install/upgrade 路由 | 存在但返回错误页 |
| addons 插件 | 500 错误 |

---

## 漏洞优先级（补天提交）

| 优先级 | 漏洞 | 等级 | 通过概率 |
|--------|------|------|----------|
| **1** | **未授权上传→RCE** | **高危** | **90%+** |
| 2 | 留言无验证码+无限提交 | 低~中危 | 45~55% |
| 3 | web.config 信息泄露 | 低危 | 高 |
| 4 | 后台爆破链 | 中危 | 30~45% |
| 5 | SSL 过期 | 低危 | 中 |

---

## 关键文件

- `rce_vuln_report.md` — RCE 完整报告
- `upload_exploit.txt` — 上传测试原始数据
- `rce_verify.txt` — phpinfo 验证
- `rce_cmd_verify.txt` — 系统信息验证
- `yzncms_routes.txt` — 路由枚举
- `brute_mega.log` — 合并字典爆破
